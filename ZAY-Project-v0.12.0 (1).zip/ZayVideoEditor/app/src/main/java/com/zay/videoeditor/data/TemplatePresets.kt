package com.zay.videoeditor.data

import com.zay.videoeditor.fx.ClipFx

/**
 * Template = kumpulan gaya siap pakai yang diterapkan otomatis ke video yang diimpor:
 * filter, transisi, gerakan, efek lapisan, judul teks, dan rasio layar.
 * Nama filter dicari lewat [ClipFx.filters]; indeks transisi/gerakan mengikuti ClipFx.transitionNames / motionNames.
 */
class TemplatePreset(
    val key: String,
    val title: String,
    val tag: String,
    val filterName: String,
    val filterStrength: Float,
    val transition: Int,
    val transitionDur: Float,
    val motion: Int,
    val motionStrength: Float,
    val fxKey: String?,
    val fxStrength: Float,
    val titleText: String?,
    val aspect: Int,
) {
    val filterIndex: Int
        get() = ClipFx.filters.indexOfFirst { it.name == filterName }.coerceAtLeast(0)
}

object TemplatePresets {
    val cinematic = TemplatePreset(
        "cinematic", "Cinematic Moments", "Sinema", "Film", 0.8f, 1, 1.0f, 3, 0.5f,
        "cinema", 70f, "Cinematic Moments", 0,
    )

    val items: List<TemplatePreset> = listOf(
        TemplatePreset("vlog", "Vlog Harian", "Vlog", "Cerah", 0.6f, 1, 0.5f, 0, 0.5f, "leak", 40f, "Vlog Harianku", 1),
        TemplatePreset("beat", "Beat Neon", "Musik", "Neon", 0.7f, 4, 0.4f, 2, 0.6f, "glitch", 60f, "BEAT", 1),
        TemplatePreset("promo", "Promosi Produk", "Bisnis", "Tajam", 0.5f, 3, 0.5f, 0, 0.5f, "vignette", 50f, "PROMO SPESIAL", 2),
        TemplatePreset("trip", "Liburan Cepat", "Vlog", "Tosca", 0.6f, 4, 0.5f, 3, 0.5f, "flare", 60f, "Liburan Seru", 0),
        TemplatePreset("lyric", "Lirik Estetik", "Musik", "Pastel", 0.7f, 1, 0.8f, 0, 0.5f, "bokeh", 60f, "Lirik Lagu", 1),
        TemplatePreset("catalog", "Slide Katalog", "Bisnis", "Asli", 0.7f, 3, 0.6f, 0, 0.5f, "neon", 50f, "KATALOG", 3),
    )
}
